
export const formatTimestamp = (isoString: string): string => {
    if (!isoString) return '';
    try {
        const date = new Date(isoString);
        if (isNaN(date.getTime())) {
          return isoString;
        }

        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);

        const messageDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());

        if (messageDate.getTime() === today.getTime()) {
            return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        }
        if (messageDate.getTime() === yesterday.getTime()) {
            return 'Yesterday';
        }
        return date.toLocaleDateString('en-GB'); // DD/MM/YYYY
    } catch (e) {
        return isoString;
    }
};

export const formatLastSeen = (isoString: string): { text: string; isOnline: boolean } => {
    if (!isoString) return { text: 'Never', isOnline: false };
    try {
        const date = new Date(isoString);
        if (isNaN(date.getTime())) {
            return { text: 'Invalid Date', isOnline: false };
        }

        const now = new Date();
        const diffSeconds = (now.getTime() - date.getTime()) / 1000;

        if (diffSeconds < 180) return { text: 'Online', isOnline: true };
        if (diffSeconds < 3600) return { text: `${Math.floor(diffSeconds / 60)}m ago`, isOnline: false };
        if (diffSeconds < 86400) return { text: `${Math.floor(diffSeconds / 3600)}h ago`, isOnline: false };
        if (diffSeconds < 2592000) return { text: `${Math.floor(diffSeconds / 86400)}d ago`, isOnline: false };
        return { text: date.toLocaleDateString('en-GB'), isOnline: false };
    } catch (e) {
        return { text: 'Invalid Date', isOnline: false };
    }
};

// Calculate distance between two coordinates in Kilometers
export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km
    return d;
};

const deg2rad = (deg: number): number => {
  return deg * (Math.PI / 180);
};

// Utility to compress images
export const compressImage = (file: File, maxWidth: number = 800, quality: number = 0.7): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = (event) => {
            const img = new Image();
            img.src = event.target?.result as string;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = (height * maxWidth) / width;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (ctx) {
                    ctx.drawImage(img, 0, 0, width, height);
                    resolve(canvas.toDataURL('image/jpeg', quality));
                } else {
                    reject(new Error("Canvas context is not available"));
                }
            };
            img.onerror = (err) => reject(err);
        };
        reader.onerror = (err) => reject(err);
    });
};
